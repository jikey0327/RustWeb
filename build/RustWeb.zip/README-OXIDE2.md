RustWeb for Oxide 2
===================
The Oxide 2 glue for RustWeb.

Installation
------------
1. If you used RustMap before, delete "Oxide.Ext.[Rust]Map.dll" from "RustDedicated_Data\Managed"
2. Make sure that your firewall allows TCP requests on your server's port
3. Copy "dcodeIO.RustWeb.dll" and "Oxide.Ext.RustWeb.dll" to "RustDedicated_Data\Managed\"
4. Copy the folder "www" next to Oxide's "data" directory (located at "server\data" by default, in this case place "www" at "server\www")
4. Restart the server

See [the project page](https://github.com/dcodeIO/RustWeb) for usage details.
